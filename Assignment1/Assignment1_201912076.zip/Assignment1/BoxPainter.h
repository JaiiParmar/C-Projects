
#pragma once

class BoxPainter
{

};