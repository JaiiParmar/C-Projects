#pragma once
#include<vector>
#include<tuple>

typedef std::vector<std::tuple<double, double, double,
	unsigned int, unsigned int>> TupleVec;

typedef unsigned int uint;

