#pragma once
#include "Transaction.h"
#include <vector>

class Statement
{
	std::vector<Transaction*> tranctions;
};

