
#include "PoS.h"
#include "BankServer.h"
#include <iostream>

bool PoS::Debit()const{
	BankServer bankServer;
	long cNo = askCardNum();
	if (bankServer.is_valid(cNo)) {


		if (BankServer.is_valid(askPin())) {
			int totAmont = askSaleTotalAmount();
			BankServer.startDebit(totAmont);
			mm->addTransaction(cNo, totAmont);
		}

	}
	else {

		return false;
	}

	return true;
}

long PoS::askCardNum()const {


}

unsigned int PoS::askPin()const {

}

unsigned int PoS::askSaleTotalAmount()const {

}

