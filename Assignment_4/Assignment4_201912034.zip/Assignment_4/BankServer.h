#pragma once
#include <vector>
#include "Account.h"

class BankServer
{
	std::vector<Account*> accounts;
	
};

