#pragma once
#include"Account.h"

class Card
{

private:
	Account* ac;
	long card_number;
	 int valid_month;
	 int valid_year;
	 int PIN;
	bool status;

public:

	Card(long, int,int, int);

	unsigned int getPIN()const;
	Account* getAcNo()const;

	unsigned int getValidYear()const;
	unsigned int getValidMonth()const;

	bool is_valid();

private:
	bool getStatus()const;
};


