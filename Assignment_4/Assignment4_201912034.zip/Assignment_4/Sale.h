#pragma once
class Sale
{
private: 
	int total;

public:
	int getTotal()const;
};

