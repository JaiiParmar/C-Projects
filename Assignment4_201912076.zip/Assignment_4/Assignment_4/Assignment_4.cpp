/*
	201912076
	Jayesh Parmar
	Assignment - 4
*/

#include <iostream>
#include "PoS.h"
#include "Marchant.h"

int main()
{
	PoS PaymentSystem;
	bool res =  PaymentSystem.Debit();
	if (res) {
		std::cout << "Ok" << std::endl;
	}
	else {
		std::cout << "NO Okay." <<std::endl;
	}
}
