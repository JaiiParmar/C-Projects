#pragma once
#include "Transaction.h"
#include <vector>

class Statement
{// Statement can have multiple transaction.
	//Statements also can be for a month, or of 10 days;
	std::vector<Transaction*> tranctions;

};

