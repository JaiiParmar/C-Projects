#pragma once
#include<string>
#include"Account.h"

class Transaction
{

private:
	unsigned int amount;
	std::string receiver;

public:


};

