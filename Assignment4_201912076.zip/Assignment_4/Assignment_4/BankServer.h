#pragma once
#include <vector>
#include "Account.h"

class BankServer
{
	std::vector<Account*> accounts;
	//assuming everything works
	/*
		Bankserver can interact with account;

		And before any making any Transaction, any payment system
		have to interact with the bank Server;


	*/
};

